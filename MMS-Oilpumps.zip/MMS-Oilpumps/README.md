# mms-oilpumps

Full Rewrite

- Creating Oilpumps that gather oil.
- Only 1 pump per Player.
- Produce Oil every time Defined in Config Oil Amount Defined in Config.
- You can get the Oil out of Pump in Pump Menu.
- Oil Pumps cant Placed in or Near Towns need a Distance of Meters (Defined in Config).
- New Function you can Enable only Place Near OilFileds in Config (Valentine Oil Fields) or Any Other Coords Working with Radius.
- Cleaned Up the Code.
- Added Better Timers and Spawn System.
- Now only 1 SQL File needed Improved Database Code 
- Now Support Language Files for Translations ( Only German Yet )
- Cleaned Config File
- Removed Crafting you Can add the Oil Item in your Vorp_Crafting or any other Crafting System The Crafting from @Fistsofury dor Example 
- You Can Now name your Pump its Also the Name of your Pumps Blip
- You can now Use a Level system for players to Upgrade their Pumps

# Changelog

- 1.1.2  Full Rewrite
- 1.1.3 Added En_lang from @Maker
- 1.1.4 Added Level System
- Changed Label Update to Menu Open Trigger It Updates Oil Amount and Stuff on Menu Open
- Cleaned Code Better Performance
- If you used Version 1.1.3 you need to Replace the Database or Add Missing Tables 
- 1.1.5 Fixed PedError ( Update Config and Client.lua  Added Config.Debug = false)
- 1.1.6 Fixed Bug that Pump is in Ground After Rejoin
- 1.1.7 Now Supports Multicharakter
- updated that oil pumps have limit, when reached stopping producing oil- update made by NastyStoner



# installation 

- Run The SQL File

# Required
- Vorp_Core
- Feather Menu by BCC https://github.com/FeatherFramework/feather-menu/releases/latest
- oxmysql

# CREDITS

- https://github.com/RetryR1v2/mms-oilpumps 